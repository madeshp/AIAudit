# AI Audit Assistant — React

A Vite + React implementation of the supplied AI Audit Assistant specification.

## Implemented
- Landing page with Create Questionnaire and Upload Questionnaire.
- Client-side `.xlsx` / `.xls` parsing with SheetJS.
- Dynamic headers from row 1; no hard-coded checklist schema.
- Automatic question-column detection with a sensible fallback.
- Empty-row skipping and malformed-row warnings.
- Review page with one card per question in original order.
- Dynamic metadata rendering.
- Answer text with blur/debounce persistence.
- Single `+ Add Evidence` control per question.
- Evidence menu with Attachments, Screenshots, JIRA, GitLab, and Datadog/Splunk links.
- Evidence items are shown as removable chips after they are added.
- Screenshot upload and clipboard paste support.
- Evidence chips with remove actions.
- Overall answered progress.
- Save to browser localStorage and export responses to JSON.
- Back-to-upload flow.
- Create Questionnaire placeholder, as required by the spec.

## Run
```bash
npm install
npm run dev
```

Then open the Vite URL shown in the terminal.

## Build
```bash
npm run build
npm run preview
```

## Notes
This is intentionally a frontend-only implementation because the supplied specification does not define backend endpoints. File objects are retained in browser memory for the active session; metadata and questionnaire responses are persisted locally where practical. The exported JSON includes attachment metadata and data URLs for attachments captured in the browser.

The supplied specification explicitly keeps automated AI validation, authentication, roles, permissions, audit versioning, and detailed questionnaire authoring outside this scope.
