import { Routes, Route } from "react-router-dom";
import LandingPage from "./pages/LandingPage";
import CreateQuestionnairePage from "./pages/CreateQuestionnairePage";
import UploadQuestionnairePage from "./pages/UploadQuestionnairePage";
import QuestionnaireReviewPage from "./pages/QuestionnaireReviewPage";

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<LandingPage />} />
      <Route path="/create" element={<CreateQuestionnairePage />} />
      <Route path="/upload" element={<UploadQuestionnairePage />} />
      <Route path="/review" element={<QuestionnaireReviewPage />} />
      <Route path="*" element={<LandingPage />} />
    </Routes>
  );
}