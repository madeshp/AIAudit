export default function ProgressBar({ value = 0 }) {
  const pct = Math.max(0, Math.min(100, value));
  return (
    <div className="progress-track" aria-label={`${pct}% complete`}>
      <div className="progress-value" style={{ width: `${pct}%` }} />
    </div>
  );
}