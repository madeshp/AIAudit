export default function Toast({ message, onClose }) {
  if (!message) return null;
  return (
    <div className="toast" role="status">
      <span>{message}</span>
      <button onClick={onClose} aria-label="Close notification">×</button>
    </div>
  );
}