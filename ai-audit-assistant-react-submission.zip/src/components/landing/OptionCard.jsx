import { ArrowRight } from "lucide-react";

export default function OptionCard({ icon, title, description, onClick }) {
  return (
    <button className="option-card" onClick={onClick}>
      <div className="option-icon">{icon}</div>
      <div className="option-copy">
        <h2>{title}</h2>
        <p>{description}</p>
      </div>
      <ArrowRight size={22} className="option-arrow" />
    </button>
  );
}