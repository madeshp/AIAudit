export default function MetadataFieldList({ metadata }) {
  return (
    <div className="metadata-grid">
      {metadata.map((field, index) => (
        <div className="metadata-field" key={`${field.headerLabel}-${index}`}>
          <span>{field.headerLabel}</span>
          <p>{field.value || "—"}</p>
        </div>
      ))}
    </div>
  );
}