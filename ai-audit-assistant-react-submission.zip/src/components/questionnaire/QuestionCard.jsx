import { useCallback, useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  CheckCircle2,
  ChevronDown,
  FileUp,
  Hash,
  ImagePlus,
  Link2,
  Plus,
  Server,
  X,
} from "lucide-react";
import MetadataFieldList from "./MetadataFieldList";
import AnswerTextBox from "../response/AnswerTextBox";
import { useQuestionnaireStore } from "../../context/QuestionnaireContext";
import { useFileAttachments } from "../../hooks/useFileAttachments";

export default function QuestionCard({ question, index }) {
  const { dispatch } = useQuestionnaireStore();
  const [evidenceOpen, setEvidenceOpen] = useState(false);
  const [linkType, setLinkType] = useState(null);
  const [linkValue, setLinkValue] = useState("");
  const evidenceButtonRef = useRef(null);
  const [menuPosition, setMenuPosition] = useState({ top: 0, left: 0 });

  const update = (patch) =>
    dispatch({ type: "UPDATE_RESPONSE", questionId: question.id, patch });

  const onFiles = useCallback(
    (records, kind) => {
      const field = kind === "screenshot" ? "screenshots" : "attachedFiles";
      update({
        [field]: [...(question.response[field] || []), ...records],
        status: "In Progress",
      });
    },
    [question.id, question.response]
  );

  const { addFiles } = useFileAttachments(question.id, onFiles);

  useEffect(() => {
    if (!evidenceOpen) return;

    const updateMenuPosition = () => {
      const button = evidenceButtonRef.current;
      if (!button) return;
      const rect = button.getBoundingClientRect();
      const menuWidth = 290;
      const menuHeight = 330;
      const gap = 8;
      const left = Math.min(
        Math.max(8, rect.left),
        Math.max(8, window.innerWidth - menuWidth - 8)
      );
      const roomBelow = window.innerHeight - rect.bottom;
      const top = roomBelow >= menuHeight + gap
        ? rect.bottom + gap
        : Math.max(8, rect.top - menuHeight - gap);
      setMenuPosition({ top, left });
    };

    updateMenuPosition();
    window.addEventListener("resize", updateMenuPosition);
    window.addEventListener("scroll", updateMenuPosition, true);
    return () => {
      window.removeEventListener("resize", updateMenuPosition);
      window.removeEventListener("scroll", updateMenuPosition, true);
    };
  }, [evidenceOpen]);

  function handleAnswer(value) {
    update({
      answerText: value,
      status: value.trim()
        ? "Answered"
        : hasEvidence(question.response)
          ? "In Progress"
          : "Not Started",
    });
  }

  function addLink(type) {
    try {
      const parsed = new URL(linkValue);
      if (!/^https?:$/.test(parsed.protocol)) throw new Error();

      const link = {
        url: linkValue,
        label: parsed.pathname.split("/").filter(Boolean).pop() || `${type} link`,
      };

      update({
        [type]: link,
        status: "In Progress",
      });
      setLinkValue("");
      setLinkType(null);
      setEvidenceOpen(false);
    } catch {
      alert("Please enter a valid URL.");
    }
  }

  function remove(kind, id) {
    dispatch({
      type: "REMOVE_EVIDENCE",
      questionId: question.id,
      kind,
      id,
    });
  }

  const attachments = [
    ...(question.response.attachedFiles || []).map((x) => ({
      id: x.id,
      kind: "file",
      label: x.fileName,
      icon: <FileUp size={14} />,
    })),
    ...(question.response.screenshots || []).map((x) => ({
      id: x.id,
      kind: "screenshot",
      label: x.fileName,
      icon: <ImagePlus size={14} />,
    })),
    question.response.jiraLink && {
      id: "jira",
      kind: "jira",
      label: `JIRA · ${question.response.jiraLink.label}`,
      icon: <Link2 size={14} />,
    },
    question.response.gitlabLink && {
      id: "gitlab",
      kind: "gitlab",
      label: `GitLab · ${question.response.gitlabLink.label}`,
      icon: <Link2 size={14} />,
    },
    question.response.datadogLink && {
      id: "datadog",
      kind: "datadog",
      label: `Datadog · ${question.response.datadogLink.label}`,
      icon: <Link2 size={14} />,
    },
    question.response.splunkLink && {
      id: "splunk",
      kind: "splunk",
      label: `Splunk · ${question.response.splunkLink.label}`,
      icon: <Link2 size={14} />,
    },
  ].filter(Boolean);

  return (
    <article className="question-card">
      <div className="question-top">
        <div className="question-number">
          <Hash size={14} />
          {String(index + 1).padStart(2, "0")}
        </div>
        <div className="status-pill">
          <span className={question.response.status === "Answered" ? "dot done" : "dot"} />
          {question.response.status}
        </div>
      </div>

      <div className="question-body">
        <h2>{question.questionText}</h2>
        <div className="row-ref">Source row {question.rowIndex}</div>
        <MetadataFieldList metadata={question.metadata} />
      </div>

      <div className="response-section">
        <div className="section-heading">
          <div>
            <span className="section-kicker">Response & Evidence</span>
            <h3>Capture audit response</h3>
          </div>
          {question.response.status === "Answered" && (
            <CheckCircle2 className="answered-icon" size={21} />
          )}
        </div>

        <AnswerTextBox
          value={question.response.answerText}
          onChange={handleAnswer}
        />

        <div className="evidence-area">
          <div className="evidence-menu-wrap">
            <button
              ref={evidenceButtonRef}
              className="add-evidence-btn"
              onClick={() => {
                setEvidenceOpen((v) => !v);
                setLinkType(null);
              }}
            >
              <Plus size={18} />
              Add Evidence
              <ChevronDown size={16} />
            </button>

            {evidenceOpen && createPortal(
              <div
                className="evidence-menu evidence-menu-overlay"
                style={{ top: menuPosition.top, left: menuPosition.left }}
                role="menu"
              >
                <button onClick={() => document.getElementById(`files-${question.id}`)?.click()}>
                  <FileUp size={17} />
                  <span>Add Attachments<small>Documents, logs, exports</small></span>
                </button>

                <button onClick={() => document.getElementById(`screenshots-${question.id}`)?.click()}>
                  <ImagePlus size={17} />
                  <span>Add Screenshots<small>Images or pasted screenshots</small></span>
                </button>

                <button onClick={() => { setLinkType("jiraLink"); setLinkValue(""); }}>
                  <Link2 size={17} />
                  <span>Add JIRA Link<small>Issue or ticket URL</small></span>
                </button>

                <button onClick={() => { setLinkType("gitlabLink"); setLinkValue(""); }}>
                  <Link2 size={17} />
                  <span>Add GitLab Link<small>Repository, MR or pipeline URL</small></span>
                </button>

                <button onClick={() => { setLinkType("datadogLink"); setLinkValue(""); }}>
                  <Server size={17} />
                  <span>Add Datadog / Splunk Link<small>Observability evidence URL</small></span>
                </button>
              </div>,
              document.body
            )}

            <input
              id={`files-${question.id}`}
              hidden
              type="file"
              multiple
              onChange={(e) => {
                addFiles(e.target.files, "file");
                e.target.value = "";
                setEvidenceOpen(false);
              }}
            />

            <input
              id={`screenshots-${question.id}`}
              hidden
              type="file"
              accept="image/*"
              multiple
              onChange={(e) => {
                addFiles(e.target.files, "screenshot");
                e.target.value = "";
                setEvidenceOpen(false);
              }}
            />
          </div>

          {linkType && (
            <div className="evidence-link-editor">
              <div className="evidence-link-title">
                <span>
                  {linkType === "jiraLink"
                    ? "JIRA"
                    : linkType === "gitlabLink"
                      ? "GitLab"
                      : "Datadog / Splunk"}{" "}
                  link
                </span>
                <button onClick={() => setLinkType(null)}><X size={15} /></button>
              </div>
              <div className="evidence-link-row">
                <input
                  autoFocus
                  value={linkValue}
                  onChange={(e) => setLinkValue(e.target.value)}
                  placeholder="https://..."
                  onKeyDown={(e) => e.key === "Enter" && addLink(linkType)}
                />
                <button
                  className="link-add"
                  disabled={!linkValue.trim()}
                  onClick={() => addLink(linkType)}
                >
                  Add
                </button>
              </div>
            </div>
          )}

          {attachments.length > 0 && (
            <div className="evidence-list">
              {attachments.map((item) => (
                <div className="evidence-chip" key={`${item.kind}-${item.id}`}>
                  {item.icon}
                  <span>{item.label}</span>
                  <button
                    onClick={() => remove(item.kind, item.id)}
                    aria-label={`Remove ${item.label}`}
                  >
                    <X size={14} />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {question.response.validation && (
        <div className={`question-validation ${question.response.validation.status === "Validated" ? "is-success" : question.response.validation.status === "Failed" ? "is-danger" : "is-warning"}`}>
          {question.response.validation.status === "Validated" ? <CheckCircle2 size={16} /> : question.response.validation.status === "Failed" ? <X size={16} /> : <Server size={16} />}
          <div>
            <strong>{question.response.validation.status}</strong>
            <span>{question.response.validation.message}</span>
          </div>
        </div>
      )}

      <div className="question-footer">
        <ChevronDown size={16} />
        Evidence is scoped to this question
      </div>
    </article>
  );
}

function hasEvidence(response) {
  return Boolean(
    response.attachedFiles?.length ||
    response.screenshots?.length ||
    response.jiraLink ||
    response.gitlabLink ||
    response.datadogLink ||
    response.splunkLink
  );
}