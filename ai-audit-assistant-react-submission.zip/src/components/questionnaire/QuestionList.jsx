import QuestionCard from "./QuestionCard";

export default function QuestionList({ questions }) {
  return (
    <div className="question-list">
      {questions.map((question, index) => (
        <QuestionCard key={question.id} question={question} index={index} />
      ))}
    </div>
  );
}