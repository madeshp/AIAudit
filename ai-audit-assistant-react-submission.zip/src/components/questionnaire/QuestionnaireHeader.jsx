import { FileSpreadsheet } from "lucide-react";
import ProgressBar from "../common/ProgressBar";

export default function QuestionnaireHeader({ questionnaire, answered }) {
  const total = questionnaire?.questions?.length || 0;
  const pct = total ? Math.round((answered / total) * 100) : 0;
  return (
    <div className="review-header">
      <div>
        <div className="eyebrow"><FileSpreadsheet size={15} /> Questionnaire Review</div>
        <h1>Audit questionnaire</h1>
        <p>{questionnaire?.sourceFileName} · {questionnaire?.sheetName}</p>
      </div>
      <div className="header-progress">
        <div><strong>{answered} of {total}</strong><span>answered</span></div>
        <ProgressBar value={pct} />
      </div>
    </div>
  );
}