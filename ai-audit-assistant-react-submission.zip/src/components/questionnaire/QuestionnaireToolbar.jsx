import { ArrowLeft, Download, Save } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Button from "../common/Button";
import { exportQuestionnaire } from "../../services/questionnaireApiService";

export default function QuestionnaireToolbar({ questionnaire, onSaved }) {
  const navigate = useNavigate();
  function save() {
    onSaved?.();
  }
  return (
    <div className="toolbar">
      <Button variant="secondary" onClick={() => navigate("/upload")}><ArrowLeft size={17} /> Back to upload</Button>
      <div className="toolbar-right">
        <Button variant="secondary" onClick={save}><Save size={17} /> Save</Button>
        <Button onClick={() => exportQuestionnaire(questionnaire)}><Download size={17} /> Export JSON</Button>
      </div>
    </div>
  );
}