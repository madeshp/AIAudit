import { useEffect, useState } from "react";

export default function AnswerTextBox({ value, onChange }) {
  const [draft, setDraft] = useState(value || "");
  useEffect(() => setDraft(value || ""), [value]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (draft !== (value || "")) onChange(draft);
    }, 600);
    return () => clearTimeout(timer);
  }, [draft]);

  return (
    <label className="control">
      <span>Audit response</span>
      <textarea
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={() => onChange(draft)}
        placeholder="Enter the response and attach the evidence if any"
        rows={5}
      />
      <small>Auto-saved after typing or when you leave the field.</small>
    </label>
  );
}