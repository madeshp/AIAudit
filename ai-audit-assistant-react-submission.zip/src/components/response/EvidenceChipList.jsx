import { ExternalLink, FileText, Image, Link2, X } from "lucide-react";

function size(n) {
  if (!n) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

export default function EvidenceChipList({ response, onRemove }) {
  const items = [];
  response.attachedFiles?.forEach((f) => items.push({ id: f.id, kind: "file", icon: <FileText size={14}/>, label: `${f.fileName} · ${size(f.size)}` }));
  response.screenshots?.forEach((f) => items.push({ id: f.id, kind: "screenshot", icon: <Image size={14}/>, label: f.fileName, image: f.dataUrl || f.url }));
  if (response.jiraLink) items.push({ id: "jira", kind: "jira", icon: <Link2 size={14}/>, label: `JIRA · ${response.jiraLink.label}`, href: response.jiraLink.url });
  if (response.gitlabLink) items.push({ id: "gitlab", kind: "gitlab", icon: <Link2 size={14}/>, label: `GitLab · ${response.gitlabLink.label}`, href: response.gitlabLink.url });

  if (!items.length) return <div className="empty-evidence">No evidence attached yet.</div>;

  return (
    <div className="evidence-list">
      {items.map((item) => (
        <div className="evidence-chip" key={`${item.kind}-${item.id}`}>
          {item.image && <img src={item.image} alt="" />}
          {!item.image && item.icon}
          {item.href ? <a href={item.href} target="_blank" rel="noreferrer">{item.label} <ExternalLink size={12}/></a> : <span>{item.label}</span>}
          <button onClick={() => onRemove(item.kind, item.id)} aria-label={`Remove ${item.label}`}><X size={14}/></button>
        </div>
      ))}
    </div>
  );
}