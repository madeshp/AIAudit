import { Paperclip } from "lucide-react";

export default function EvidenceUploader({ onFiles }) {
  return (
    <label className="evidence-control">
      <input type="file" multiple onChange={(e) => onFiles(e.target.files)} />
      <Paperclip size={18} />
      <span><b>Attach evidence</b><small>Logs, documents, exports and other supporting files</small></span>
    </label>
  );
}