import { useState } from "react";
import { ExternalLink, Plus } from "lucide-react";

export default function GitlabLinkInput({ value, onAdd }) {
  const [url, setUrl] = useState("");
  function add() {
    try {
      const parsed = new URL(url);
      if (!/^https?:$/.test(parsed.protocol)) throw new Error();
      onAdd({ url, label: parsed.pathname.split("/").filter(Boolean).pop() || "GitLab link" });
      setUrl("");
    } catch {
      alert("Please enter a valid GitLab URL.");
    }
  }
  if (value) return (
    <div className="link-chip-row">
      <span className="source-label gitlab">GITLAB</span>
      <a href={value.url} target="_blank" rel="noreferrer">{value.label} <ExternalLink size={13}/></a>
    </div>
  );
  return (
    <div className="link-input">
      <span>GitLab link</span>
      <div>
        <input value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://gitlab.example.com/group/project/-/merge_requests/12" />
        <button onClick={add} disabled={!url.trim()}><Plus size={16}/> Add</button>
      </div>
    </div>
  );
}