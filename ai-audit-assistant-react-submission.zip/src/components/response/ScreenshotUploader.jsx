import { useEffect, useRef } from "react";
import { ImagePlus } from "lucide-react";

export default function ScreenshotUploader({ onFiles }) {
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => {
      const items = Array.from(e.clipboardData?.items || []);
      const images = items.map((item) => item.kind === "file" ? item.getAsFile() : null).filter(Boolean);
      if (images.length) onFiles(images);
    };
    window.addEventListener("paste", handler);
    return () => window.removeEventListener("paste", handler);
  }, [onFiles]);

  return (
    <label className="screenshot-box">
      <input ref={ref} type="file" accept="image/*" multiple onChange={(e) => onFiles(e.target.files)} />
      <ImagePlus size={20} />
      <div><b>Add screenshots</b><span>Drop, browse, or paste an image</span></div>
    </label>
  );
}