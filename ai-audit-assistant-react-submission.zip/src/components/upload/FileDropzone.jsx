import { useRef, useState } from "react";
import { FileSpreadsheet, UploadCloud } from "lucide-react";

export default function FileDropzone({ onFile, disabled }) {
  const inputRef = useRef(null);
  const [dragging, setDragging] = useState(false);

  function accept(file) {
    if (!file) return;
    const valid = /\.(xlsx|xls)$/i.test(file.name);
    if (!valid) {
      onFile(null, "Please select an .xlsx or .xls file.");
      return;
    }
    onFile(file);
  }

  return (
    <div
      className={`dropzone ${dragging ? "dragging" : ""}`}
      onDragOver={(e) => { e.preventDefault(); setDragging(true); }}
      onDragLeave={() => setDragging(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDragging(false);
        accept(e.dataTransfer.files?.[0]);
      }}
      onClick={() => !disabled && inputRef.current?.click()}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => e.key === "Enter" && inputRef.current?.click()}
    >
      <input
        ref={inputRef}
        hidden
        type="file"
        accept=".xlsx,.xls,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel"
        onChange={(e) => accept(e.target.files?.[0])}
      />
      <div className="drop-icon"><UploadCloud size={30} /></div>
      <h3>Drop your questionnaire here</h3>
      <p>or click to browse your computer</p>
      <span className="file-hint"><FileSpreadsheet size={16} /> Excel files only · .xlsx / .xls</span>
    </div>
  );
}