import { AlertTriangle, CheckCircle2, FileSpreadsheet } from "lucide-react";

export default function UploadSummary({ questionnaire }) {
  if (!questionnaire) return null;
  return (
    <div className="upload-summary">
      <div className="summary-top">
        <div className="summary-file">
          <div className="file-icon"><FileSpreadsheet size={22} /></div>
          <div>
            <strong>{questionnaire.sourceFileName}</strong>
            <span>Sheet: {questionnaire.sheetName}</span>
          </div>
        </div>
        <div className="summary-count">
          <b>{questionnaire.questions.length}</b>
          <span>questions</span>
        </div>
      </div>
      <div className="summary-status">
        {questionnaire.questions.length > 0 ? <CheckCircle2 size={18} /> : <AlertTriangle size={18} />}
        {questionnaire.questions.length > 0 ? "Workbook parsed successfully." : "No questions detected."}
      </div>
      {questionnaire.warnings?.length > 0 && (
        <div className="warning-list">
          <strong>Warnings</strong>
          {questionnaire.warnings.map((warning, i) => <div key={i}>• {warning}</div>)}
        </div>
      )}
    </div>
  );
}