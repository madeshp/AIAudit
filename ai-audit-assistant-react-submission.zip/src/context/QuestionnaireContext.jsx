import { createContext, useContext, useEffect, useReducer } from "react";
import {
  clearQuestionnaireLocal,
  loadQuestionnaireLocal,
  saveQuestionnaireLocal,
} from "../services/questionnaireApiService";

const Context = createContext(null);

function reducer(state, action) {
  switch (action.type) {
    case "SET_QUESTIONNAIRE":
      return action.payload;
    case "UPDATE_RESPONSE": {
      if (!state) return state;
      return {
        ...state,
        questions: state.questions.map((q) =>
          q.id === action.questionId
            ? {
                ...q,
                response: {
                  ...q.response,
                  ...action.patch,
                },
              }
            : q
        ),
      };
    }
    case "UPDATE_VALIDATION": {
      if (!state) return state;
      return {
        ...state,
        questions: state.questions.map((q) =>
          q.id === action.questionId
            ? { ...q, response: { ...q.response, validation: action.validation } }
            : q
        ),
      };
    }
    case "REMOVE_EVIDENCE": {
      if (!state) return state;
      return {
        ...state,
        questions: state.questions.map((q) => {
          if (q.id !== action.questionId) return q;
          const response = { ...q.response };
          if (action.kind === "file") {
            response.attachedFiles = response.attachedFiles.filter((x) => x.id !== action.id);
          } else if (action.kind === "screenshot") {
            response.screenshots = response.screenshots.filter((x) => x.id !== action.id);
          } else if (action.kind === "jira") {
            response.jiraLink = null;
          } else if (action.kind === "gitlab") {
            response.gitlabLink = null;
          } else if (action.kind === "datadog") {
            response.datadogLink = null;
          } else if (action.kind === "splunk") {
            response.splunkLink = null;
          }
          return { ...q, response };
        }),
      };
    }
    case "CLEAR":
      clearQuestionnaireLocal();
      return null;
    default:
      return state;
  }
}

export function QuestionnaireProvider({ children }) {
  const [questionnaire, dispatch] = useReducer(
    reducer,
    undefined,
    () => loadQuestionnaireLocal()
  );

  useEffect(() => {
    if (questionnaire) saveQuestionnaireLocal(questionnaire);
  }, [questionnaire]);

  return (
    <Context.Provider value={{ questionnaire, dispatch }}>
      {children}
    </Context.Provider>
  );
}

export function useQuestionnaireStore() {
  const value = useContext(Context);
  if (!value) throw new Error("useQuestionnaireStore must be used within QuestionnaireProvider");
  return value;
}