import { useState } from "react";
import { parseExcelFile } from "../services/excelParserService";

export function useExcelParser() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function parse(file) {
    setLoading(true);
    setError("");
    try {
      return await parseExcelFile(file);
    } catch (err) {
      setError(err?.message || "Unable to parse the workbook.");
      return null;
    } finally {
      setLoading(false);
    }
  }

  return { parse, loading, error };
}