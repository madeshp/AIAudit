import { useCallback } from "react";
import { saveAttachment } from "../services/fileStorageService";

export function useFileAttachments(questionId, onFiles) {
  const addFiles = useCallback(
    async (files, kind = "file") => {
      const selected = Array.from(files || []);
      const records = [];
      for (const file of selected) {
        const record = await saveAttachment(file, questionId, kind);
        if (record) records.push(record);
      }
      if (records.length) onFiles(records, kind);
    },
    [questionId, onFiles]
  );

  return { addFiles };
}