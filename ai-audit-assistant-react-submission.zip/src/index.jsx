import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import { QuestionnaireProvider } from "./context/QuestionnaireContext";
import "./styles/global.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <QuestionnaireProvider>
        <App />
      </QuestionnaireProvider>
    </BrowserRouter>
  </React.StrictMode>
);