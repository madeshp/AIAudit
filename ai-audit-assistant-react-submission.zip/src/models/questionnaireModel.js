export function createQuestionnaire({ sourceFileName, sheetName, headers, questions, warnings = [] }) {
  return {
    id: crypto.randomUUID(),
    sourceFileName,
    sheetName,
    uploadedAt: new Date().toISOString(),
    headers,
    questions,
    warnings,
  };
}

export function createQuestion({ rowIndex, questionText, metadata }) {
  return {
    id: crypto.randomUUID(),
    rowIndex,
    questionText,
    metadata,
    response: {
      answerText: "",
      attachedFiles: [],
      screenshots: [],
      jiraLink: null,
      gitlabLink: null,
      status: "Not Started",
      validation: null,
    },
  };
}