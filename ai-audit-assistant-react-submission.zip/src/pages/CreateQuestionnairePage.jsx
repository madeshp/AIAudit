import { ArrowLeft, ClipboardList, Construction } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Button from "../components/common/Button";

export default function CreateQuestionnairePage() {
  const navigate = useNavigate();
  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="back-link" onClick={() => navigate("/")}><ArrowLeft size={17}/> Back</button>
        <div className="brand compact"><div className="brand-mark"><ClipboardList size={19}/></div><b>AI Audit Assistant</b></div>
      </header>
      <section className="placeholder-page">
        <div className="placeholder-icon"><Construction size={34}/></div>
        <span className="eyebrow">Create Questionnaire</span>
        <h1>Manual authoring is outside this specification</h1>
        <p>The supplied functional specification defines this as a navigable placeholder. The upload and review workflow is fully implemented.</p>
        <Button onClick={() => navigate("/upload")}>Upload an Excel questionnaire</Button>
      </section>
    </main>
  );
}