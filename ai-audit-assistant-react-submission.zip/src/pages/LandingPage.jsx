import { ClipboardList, FileUp, ShieldCheck, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";
import OptionCard from "../components/landing/OptionCard";

export default function LandingPage() {
  const navigate = useNavigate();
  return (
    <main className="app-shell landing">
      <header className="brand">
        <div className="brand-mark"><ShieldCheck size={24}/></div>
        <div><b>AI Audit Assistant</b><span>AI Use-Case Review</span></div>
      </header>

      <section className="hero">
        <div className="hero-badge"><Sparkles size={15}/> Audit-ready questionnaire workspace</div>
        <h1>Review AI use cases<br/><em>with confidence.</em></h1>
        <p>Load an audit checklist, capture responses, and organize evidence for every requirement in one focused workspace.</p>

        <div className="entry-grid">
          <OptionCard
            icon={<ClipboardList size={28}/>}
            title="Create Questionnaire"
            description="Start a questionnaire manually. Authoring details are reserved for a future scope."
            onClick={() => navigate("/create")}
          />
          <OptionCard
            icon={<FileUp size={28}/>}
            title="Upload Questionnaire"
            description="Import an Excel checklist and turn each row into an interactive audit question."
            onClick={() => navigate("/upload")}
          />
        </div>
      </section>

      <footer className="landing-footer">Client-side questionnaire workspace · Frontend implementation</footer>
    </main>
  );
}