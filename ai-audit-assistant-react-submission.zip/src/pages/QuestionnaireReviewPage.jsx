import { useMemo, useState } from "react";
import { CheckCircle2, ClipboardCheck, Loader2, Send, XCircle, AlertTriangle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import QuestionnaireHeader from "../components/questionnaire/QuestionnaireHeader";
import QuestionnaireToolbar from "../components/questionnaire/QuestionnaireToolbar";
import QuestionList from "../components/questionnaire/QuestionList";
import Toast from "../components/common/Toast";
import { useQuestionnaireStore } from "../context/QuestionnaireContext";
import { submitQuestionnaire } from "../services/questionnaireApiService";

export default function QuestionnaireReviewPage() {
  const navigate = useNavigate();
  const { questionnaire, dispatch } = useQuestionnaireStore();
  const [toast, setToast] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitResult, setSubmitResult] = useState(null);

  const answered = useMemo(
    () => questionnaire?.questions?.filter((q) => q.response.status === "Answered").length || 0,
    [questionnaire]
  );

  const summary = useMemo(() => {
    const results = submitResult?.results || [];
    return {
      validated: results.filter((r) => r.status === "Validated").length,
      failed: results.filter((r) => r.status === "Failed").length,
      insufficient: results.filter((r) => r.status === "Evidence Insufficient").length,
    };
  }, [submitResult]);

  if (!questionnaire) {
    return (
      <main className="app-shell">
        <div className="empty-state">
          <ClipboardCheck size={38}/>
          <h1>No questionnaire loaded</h1>
          <p>Upload an Excel questionnaire to start the audit review.</p>
          <button className="btn btn-primary" onClick={() => navigate("/upload")}>Upload questionnaire</button>
        </div>
      </main>
    );
  }

  async function handleSubmit() {
    if (submitting) return;
    setSubmitting(true);
    setSubmitResult(null);
    setToast("");

    try {
      const result = await submitQuestionnaire(questionnaire);
      setSubmitResult(result);

      result.results.forEach((item) => {
        dispatch({
          type: "UPDATE_VALIDATION",
          questionId: item.questionId,
          validation: {
            status: item.status,
            message: item.message,
            submittedAt: result.submittedAt,
          },
        });
      });
    } catch (error) {
      console.error("Questionnaire submission failed", error);
      setToast("Submission failed. Please try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <main className="app-shell review">
      <header className="topbar">
        <div className="brand compact"><div className="brand-mark"><ClipboardCheck size={19}/></div><b>AI Audit Assistant</b></div>
        <span className="session-label">Local review session</span>
      </header>

      <div className="review-wrap">
        <QuestionnaireHeader questionnaire={questionnaire} answered={answered} />
        <QuestionnaireToolbar questionnaire={questionnaire} onSaved={() => setToast("Questionnaire saved locally.")} />
        {questionnaire.warnings?.length > 0 && (
          <div className="review-notice">
            <strong>Import warnings:</strong> {questionnaire.warnings.length} item(s) were flagged during parsing. Review the upload summary if needed.
          </div>
        )}

        {submitResult && (
          <section className="submission-result" aria-live="polite">
            <div className="submission-result-head">
              <div>
                <span className="section-kicker">Validation result</span>
                <h2>Questionnaire submitted</h2>
                <p>Request <strong>{submitResult.requestId}</strong> returned a partial validation result.</p>
              </div>
              <button className="icon-btn" onClick={() => setSubmitResult(null)} aria-label="Close result"><XCircle size={19}/></button>
            </div>
            <div className="validation-summary">
              <div className="validation-stat success"><CheckCircle2 size={18}/><b>{summary.validated}</b><span>Validated</span></div>
              <div className="validation-stat warning"><AlertTriangle size={18}/><b>{summary.insufficient}</b><span>More evidence</span></div>
              <div className="validation-stat danger"><XCircle size={18}/><b>{summary.failed}</b><span>Failed</span></div>
            </div>
            <div className="validation-note">
              <strong>What to do next:</strong> Items marked “More evidence” need additional supporting evidence. Failed items need the response reviewed and corrected.
            </div>
          </section>
        )}

        <QuestionList questions={questionnaire.questions} />

        <div className="submit-area">
          <div>
            <strong>Ready to submit?</strong>
            <span>The questionnaire will be sent to the audit validation API.</span>
          </div>
          <button className="btn btn-primary submit-btn" onClick={handleSubmit} disabled={submitting}>
            {submitting ? <><Loader2 size={17} className="spin" /> Validating…</> : <><Send size={17} /> Submit Questionnaire</>}
          </button>
        </div>
      </div>
      <Toast message={toast} onClose={() => setToast("")} />
    </main>
  );
}
