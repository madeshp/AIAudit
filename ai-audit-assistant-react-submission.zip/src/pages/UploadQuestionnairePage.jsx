import { useState } from "react";
import { ArrowLeft, ArrowRight, FileSpreadsheet, LoaderCircle } from "lucide-react";
import { useNavigate } from "react-router-dom";
import FileDropzone from "../components/upload/FileDropzone";
import UploadSummary from "../components/upload/UploadSummary";
import Button from "../components/common/Button";
import Toast from "../components/common/Toast";
import { useExcelParser } from "../hooks/useExcelParser";
import { useQuestionnaireStore } from "../context/QuestionnaireContext";

export default function UploadQuestionnairePage() {
  const navigate = useNavigate();
  const { dispatch } = useQuestionnaireStore();
  const { parse, loading, error } = useExcelParser();
  const [questionnaire, setQuestionnaire] = useState(null);
  const [toast, setToast] = useState("");

  async function handleFile(file, validationError) {
    if (validationError) {
      setToast(validationError);
      return;
    }
    const result = await parse(file);
    if (result) setQuestionnaire(result);
  }

  function continueToReview() {
    if (!questionnaire?.questions?.length) {
      setToast("Please upload a workbook containing at least one question.");
      return;
    }
    dispatch({ type: "SET_QUESTIONNAIRE", payload: questionnaire });
    navigate("/review");
  }

  return (
    <main className="app-shell">
      <header className="topbar">
        <button className="back-link" onClick={() => navigate("/")}><ArrowLeft size={17}/> Back to home</button>
        <div className="brand compact"><div className="brand-mark"><FileSpreadsheet size={19}/></div><b>Upload Questionnaire</b></div>
      </header>

      <section className="upload-page">
        <div className="page-heading">
          <span className="eyebrow">Step 1 · Import</span>
          <h1>Upload your audit questionnaire</h1>
          <p>We’ll read row 1 as dynamic headers and create one review card for every populated question row.</p>
        </div>

        <FileDropzone onFile={handleFile} disabled={loading} />

        {loading && <div className="parsing"><LoaderCircle className="spin" size={19}/> Parsing workbook in your browser…</div>}
        {error && <div className="inline-error">{error}</div>}

        <UploadSummary questionnaire={questionnaire} />

        <div className="upload-actions">
          <Button variant="secondary" onClick={() => navigate("/")}>Cancel</Button>
          <Button onClick={continueToReview} disabled={!questionnaire?.questions?.length || loading}>
            Continue to review <ArrowRight size={17}/>
          </Button>
        </div>
      </section>

      <Toast message={toast} onClose={() => setToast("")} />
    </main>
  );
}