// Routes are declared in src/App.jsx to keep this small implementation easy to run.
export default function AppRoutes() { return null; }