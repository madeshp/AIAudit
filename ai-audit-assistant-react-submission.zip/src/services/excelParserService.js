import * as XLSX from "xlsx";
import { createQuestion, createQuestionnaire } from "../models/questionnaireModel";

function normalizeHeader(value) {
  return String(value ?? "").trim();
}

function findQuestionColumn(headers) {
  const exact = headers.findIndex(
    (h) => h.toLowerCase() === "audit question / requirement"
  );
  if (exact >= 0) return exact;

  const semantic = headers.findIndex((h) => {
    const s = h.toLowerCase();
    return (
      s.includes("question") ||
      s.includes("requirement") ||
      s.includes("audit question")
    );
  });
  return semantic >= 0 ? semantic : 0;
}

export async function parseExcelFile(file) {
  if (!file) throw new Error("No file selected.");
  const lower = file.name.toLowerCase();
  if (!lower.endsWith(".xlsx") && !lower.endsWith(".xls")) {
    throw new Error("Please select an Excel .xlsx or .xls file.");
  }

  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });

  if (!workbook.SheetNames.length) {
    throw new Error("The workbook does not contain any sheets.");
  }

  const sheetName =
    workbook.SheetNames.find((n) => n.toLowerCase() === "audit requirements") ||
    workbook.SheetNames[0];

  const sheet = workbook.Sheets[sheetName];
  const rows = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    defval: "",
    raw: false,
  });

  if (!rows.length) throw new Error("The selected sheet is empty.");

  const rawHeaders = rows[0] || [];
  const headers = rawHeaders.map(normalizeHeader);

  const warnings = [];
  const usableHeaderIndexes = [];
  const seen = new Map();

  headers.forEach((header, index) => {
    if (!header) {
      warnings.push(`Column ${index + 1} has an empty header and was ignored.`);
      return;
    }
    const count = (seen.get(header.toLowerCase()) || 0) + 1;
    seen.set(header.toLowerCase(), count);
    usableHeaderIndexes.push(index);
  });

  if (!usableHeaderIndexes.length) {
    throw new Error("No non-empty column headers were found in row 1.");
  }

  const questionColumn = findQuestionColumn(headers);
  if (!headers[questionColumn]) {
    throw new Error("Could not identify a question column.");
  }

  const questions = [];

  for (let r = 1; r < rows.length; r++) {
    const row = rows[r] || [];
    const hasAnyValue = row.some((value) => String(value ?? "").trim() !== "");
    if (!hasAnyValue) continue;

    const questionText = String(row[questionColumn] ?? "").trim();

    if (!questionText) {
      warnings.push(`Row ${r + 1}: data exists, but the question field is empty.`);
      continue;
    }

    const metadata = usableHeaderIndexes
      .filter((index) => index !== questionColumn)
      .map((index) => ({
        headerLabel: headers[index],
        value: String(row[index] ?? "").trim(),
      }));

    questions.push(
      createQuestion({
        rowIndex: r + 1,
        questionText,
        metadata,
      })
    );
  }

  if (!questions.length) {
    warnings.push("No questions were detected in the selected sheet.");
  }

  return createQuestionnaire({
    sourceFileName: file.name,
    sheetName,
    headers: usableHeaderIndexes.map((i) => headers[i]),
    questions,
    warnings,
  });
}