const DB_NAME = "ai-audit-assistant";
const STORE_NAME = "attachments";

function openDb() {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 1);
    request.onupgradeneeded = () => {
      request.result.createObjectStore(STORE_NAME, { keyPath: "id" });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function saveAttachment(file, questionId, kind = "file") {
  if (!file) return null;
  const id = crypto.randomUUID();
  const dataUrl = await readAsDataURL(file);
  const record = {
    id,
    questionId,
    kind,
    fileName: file.name,
    fileType: file.type || "application/octet-stream",
    size: file.size,
    uploadedAt: new Date().toISOString(),
    dataUrl,
  };

  try {
    const db = await openDb();
    await new Promise((resolve, reject) => {
      const tx = db.transaction(STORE_NAME, "readwrite");
      tx.objectStore(STORE_NAME).put(record);
      tx.oncomplete = resolve;
      tx.onerror = () => reject(tx.error);
    });
  } catch {
    // The app still works without IndexedDB; the data URL is retained in state.
  }

  return {
    id,
    fileName: record.fileName,
    fileType: record.fileType,
    size: record.size,
    uploadedAt: record.uploadedAt,
    url: dataUrl,
    dataUrl,
  };
}

function readAsDataURL(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error);
    reader.readAsDataURL(file);
  });
}