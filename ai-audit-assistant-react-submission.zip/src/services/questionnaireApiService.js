const STORAGE_KEY = "ai-audit-assistant-questionnaire";

export function saveQuestionnaireLocal(questionnaire) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(questionnaire));
}

export function loadQuestionnaireLocal() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function clearQuestionnaireLocal() {
  localStorage.removeItem(STORAGE_KEY);
}

/**
 * Mock API boundary for audit submission.
 * Replace the implementation inside this function with fetch('/api/...')
 * when the real backend is available. The UI already consumes the same
 * response contract.
 */
export async function submitQuestionnaire(questionnaire) {
  const payload = {
    questionnaireId: questionnaire.id,
    sourceFileName: questionnaire.sourceFileName,
    sheetName: questionnaire.sheetName,
    questions: questionnaire.questions.map((q, index) => ({
      questionId: q.id,
      questionText: q.questionText,
      answer: q.response.answerText,
      evidence: {
        attachments: (q.response.attachedFiles || []).map((x) => x.fileName),
        screenshots: (q.response.screenshots || []).map((x) => x.fileName),
        jira: q.response.jiraLink?.url || null,
        gitlab: q.response.gitlabLink?.url || null,
        datadog: q.response.datadogLink?.url || null,
        splunk: q.response.splunkLink?.url || null,
      },
      rowIndex: q.rowIndex,
      sequence: index + 1,
    })),
  };

  // Simulates the network/API boundary and deterministic validation results.
  await new Promise((resolve) => setTimeout(resolve, 1100));

  const results = questionnaire.questions.map((q, index) => {
    const answer = (q.response.answerText || "").trim();
    const evidenceCount =
      (q.response.attachedFiles?.length || 0) +
      (q.response.screenshots?.length || 0) +
      (q.response.jiraLink ? 1 : 0) +
      (q.response.gitlabLink ? 1 : 0) +
      (q.response.datadogLink ? 1 : 0) +
      (q.response.splunkLink ? 1 : 0);

    // Mix outcomes so the prototype demonstrates all validation states.
    // Real validation should come from the backend response instead.
    let status;
    let message;
    if (index % 3 === 0 && answer && evidenceCount > 0) {
      status = "Validated";
      message = "Response and supporting evidence are sufficient.";
    } else if (index % 3 === 1 || !answer) {
      status = "Failed";
      message = !answer
        ? "A response is required before this item can be validated."
        : "The response did not satisfy the validation criteria.";
    } else {
      status = "Evidence Insufficient";
      message = "The response is present, but additional supporting evidence is required.";
    }

    return {
      questionId: q.id,
      status,
      message,
      evidenceCount,
    };
  });

  return {
    success: true,
    requestId: `MOCK-${Date.now()}`,
    submittedAt: new Date().toISOString(),
    payload,
    results,
  };
}

export function exportQuestionnaire(questionnaire) {
  const blob = new Blob([JSON.stringify(questionnaire, null, 2)], {
    type: "application/json",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `${questionnaire.sourceFileName.replace(/\.(xlsx|xls)$/i, "")}-responses.json`;
  anchor.click();
  URL.revokeObjectURL(url);
}
