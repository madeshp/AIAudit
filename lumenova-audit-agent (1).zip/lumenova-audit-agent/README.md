# Lumenova Guardrails Audit Agent

A FastAPI service that backs the **AI Audit Assistant portal** for the control:

> **AI Guardrails #8** — Provide support for the decision that Lumenova was
> implemented and tested in a lower environment but determined not required
> for this use case (testing evidence, meeting minutes, documented decision).

## What it does

1. Portal user submits evidence: a GitLab repository location (+ branch,
   optional access token) and, if applicable, text of a decision memo /
   meeting minutes / test report.
2. The agent shallow-clones the repo, scans it for any mention of
   **Lumenova** across dependency files, config, source code, and docs.
3. An LLM (any OpenAI-API-compatible model) reviews the extracted evidence
   and judges whether Lumenova is **genuinely implemented** (not just
   mentioned in a comment).
4. If it's not implemented, the LLM separately judges whether the submitted
   decision memo / minutes **adequately document the exception** (tested in
   lower env, decision made it's not required here).
5. Final verdict is derived and persisted:

   | Code implements Lumenova | Exception well documented | Verdict |
   |---|---|---|
   | Yes | — | **Passed** |
   | No | Yes | **Partial** |
   | No | No | **Failed** |

## Project layout

```
app/
  main.py              FastAPI routes (submit / poll / list)
  models.py            Pydantic request/response/report models
  config.py             Environment-driven settings
  gitlab_agent.py       Repo checkout (git clone with token injection)
  lumenova_checker.py   Static scan for "Lumenova" signals
  llm_agent.py           OpenAI-compatible LLM auditor (strict JSON output)
  audit_engine.py        Orchestrates the whole pipeline, derives verdict
  storage.py             Flat-file JSON persistence (swap for a DB in prod)
requirements.txt
Dockerfile
run.sh
.env.example
```

## Setup

```bash
cp .env.example .env
# edit .env: set OPENAI_API_KEY (and OPENAI_BASE_URL/OPENAI_MODEL if not
# using stock OpenAI), and optionally GITLAB_DEFAULT_TOKEN

./run.sh
# or: docker build -t lumenova-audit-agent . && docker run --env-file .env -p 8000:8000 lumenova-audit-agent
```

The API is then live at `http://localhost:8000` with interactive docs at
`http://localhost:8000/docs`.

## API

### `POST /api/v1/audit/submit`

```json
{
  "requirement_id": "AI-Guardrails-8",
  "submitted_by": "jane.doe@company.com",
  "gitlab_url": "https://gitlab.com/myorg/myproject.git",
  "branch": "main",
  "gitlab_token": "glpat-xxxxxxxxxxxxxxxxxxxx",
  "evidence_documents": [
    {
      "title": "Lumenova Exception Decision Memo",
      "source": "Confluence",
      "content": "On 2026-06-12 the AI Risk team tested Lumenova in the QA environment against the customer-support-bot use case... After review, it was determined Lumenova's guardrails were redundant with the existing PII-redaction layer, and the team decided not to deploy it to production. Test evidence attached: ..."
    }
  ]
}
```

Response:
```json
{
  "audit_id": "6f1c9e0a-....",
  "status": "queued",
  "message": "Audit queued. Poll GET /api/v1/audit/{audit_id} for results."
}
```

### `GET /api/v1/audit/{audit_id}`

Poll until `status` is `completed` (or `error`). Example completed response:

```json
{
  "audit_id": "6f1c9e0a-....",
  "status": "completed",
  "verdict": "Partial",
  "findings_count": 3,
  "code_assessment": {
    "implemented": false,
    "confidence": 0.92,
    "rationale": "Lumenova is only referenced in a code comment and a stale requirements.txt entry that is commented out; no active integration was found.",
    "evidence_used": ["requirements.txt:14", "app/middleware.py:22"]
  },
  "decision_evidence_assessment": {
    "adequately_documented": true,
    "confidence": 0.81,
    "rationale": "The decision memo documents lower-environment testing, references specific test evidence, and gives a substantive rationale for the exception.",
    "missing_elements": []
  }
}
```

### `GET /api/v1/audit`

Lists all audits, most recent first.

## Notes / production hardening

- **Token handling**: tokens are only ever used in-memory to build the clone
  URL and are redacted from any error output; they are never logged or persisted.
- **Background execution** uses FastAPI's `BackgroundTasks` for simplicity —
  for high volume, swap `run_audit` into a Celery/RQ/Arq worker queue.
- **Storage** is flat JSON files under `AUDIT_DATA_DIR` — swap `app/storage.py`
  for a real database in production.
- **LLM provider**: works with OpenAI directly, or any OpenAI-compatible
  gateway (Azure OpenAI, LiteLLM proxy, self-hosted vLLM, etc.) by changing
  `OPENAI_BASE_URL` / `OPENAI_MODEL`.
- The scanner is a **signal extractor only** — it never makes the pass/fail
  call itself; that judgement is left to the LLM auditor working from the
  extracted evidence, exactly as a human auditor would.
