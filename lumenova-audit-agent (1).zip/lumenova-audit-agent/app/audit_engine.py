"""
Orchestrates a single end-to-end audit run:

  1. Checkout the GitLab repo at the requested branch
  2. Scan for Lumenova implementation signals
  3. Ask the LLM whether those signals amount to a real implementation
  4. If NOT implemented in code, ask the LLM whether the submitted
     decision memo / meeting minutes / test evidence adequately document
     the "tested but determined not required" exception
  5. Derive a final verdict and persist the report

Verdict logic (mirrors the control's own status vocabulary: Passed / Partial / Failed):
  - Lumenova implemented in code                                  -> Passed
  - Not implemented, but exception is well documented              -> Partial
  - Not implemented, and exception evidence missing/inadequate     -> Failed
"""
import logging
from datetime import datetime, timezone

from app.gitlab_agent import GitLabCheckoutError, checkout_repository, cleanup_checkout
from app.llm_agent import LLMAuditor
from app.lumenova_checker import scan_repository
from app.models import (
    AuditReport,
    AuditStatus,
    AuditSubmissionRequest,
    RequirementVerdict,
)
from app.storage import save_report

logger = logging.getLogger("lumenova_audit.engine")


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _update(report: AuditReport, **kwargs) -> None:
    for k, v in kwargs.items():
        setattr(report, k, v)
    report.updated_at = _now()
    save_report(report)


def run_audit(audit_id: str, request: AuditSubmissionRequest) -> None:
    """
    Synchronous worker function — intended to be invoked from a FastAPI
    BackgroundTask (or a Celery/RQ worker in a heavier deployment).
    """
    report = AuditReport(
        audit_id=audit_id,
        requirement_id=request.requirement_id,
        submitted_by=request.submitted_by,
        gitlab_url=str(request.gitlab_url),
        branch=request.branch,
        status=AuditStatus.QUEUED,
        created_at=_now(),
        updated_at=_now(),
    )
    save_report(report)

    checkout_path = None
    try:
        # --- 1. Checkout -----------------------------------------------------
        _update(report, status=AuditStatus.CLONING)
        checkout_path = checkout_repository(
            gitlab_url=str(request.gitlab_url),
            branch=request.branch,
            token=request.gitlab_token,
            audit_id=audit_id,
        )

        # --- 2. Scan -----------------------------------------------------------
        _update(report, status=AuditStatus.SCANNING)
        findings = scan_repository(checkout_path, subdirectory=request.subdirectory)

        # --- 3. LLM: is it actually implemented? --------------------------------
        _update(report, status=AuditStatus.EVALUATING, findings=findings, findings_count=len(findings))
        auditor = LLMAuditor()
        code_assessment = auditor.assess_code_implementation(findings)

        decision_assessment = None
        if code_assessment.implemented:
            verdict = RequirementVerdict.PASSED
        else:
            # --- 4. LLM: is the "not required" exception well documented? -----
            decision_assessment = auditor.assess_decision_evidence(
                request.evidence_documents, request.requirement_text
            )
            verdict = (
                RequirementVerdict.PARTIAL
                if decision_assessment.adequately_documented
                else RequirementVerdict.FAILED
            )

        _update(
            report,
            status=AuditStatus.COMPLETED,
            verdict=verdict,
            code_assessment=code_assessment,
            decision_evidence_assessment=decision_assessment,
        )
        logger.info("Audit %s completed with verdict %s", audit_id, verdict)

    except GitLabCheckoutError as exc:
        logger.error("Audit %s: checkout failed: %s", audit_id, exc)
        _update(report, status=AuditStatus.ERROR, verdict=RequirementVerdict.FAILED, error=str(exc))
    except Exception as exc:  # noqa: BLE001
        logger.exception("Audit %s failed unexpectedly", audit_id)
        _update(report, status=AuditStatus.ERROR, verdict=RequirementVerdict.FAILED, error=str(exc))
    finally:
        if checkout_path is not None:
            cleanup_checkout(checkout_path)
