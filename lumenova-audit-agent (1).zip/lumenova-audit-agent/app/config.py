"""
Central configuration for the Lumenova Audit Agent.

All values are sourced from environment variables (or a .env file loaded by
python-dotenv) so the service can be dropped into any environment without
code changes.
"""
from functools import lru_cache
from pydantic_settings import BaseSettings
from pydantic import Field


class Settings(BaseSettings):
    # --- LLM (OpenAI-compatible) settings -----------------------------------
    openai_api_key: str = Field(default="", alias="OPENAI_API_KEY")
    # Override this to point at Azure OpenAI, a local vLLM/OpenAI-compatible
    # gateway, or any other OpenAI-API-compatible endpoint.
    openai_base_url: str = Field(default="https://api.openai.com/v1", alias="OPENAI_BASE_URL")
    openai_model: str = Field(default="gpt-4o-mini", alias="OPENAI_MODEL")
    llm_temperature: float = Field(default=0.0, alias="LLM_TEMPERATURE")
    llm_max_output_tokens: int = Field(default=1200, alias="LLM_MAX_OUTPUT_TOKENS")

    # --- GitLab settings ------------------------------------------------------
    # Fallback token used if the caller doesn't supply one per-request.
    gitlab_default_token: str = Field(default="", alias="GITLAB_DEFAULT_TOKEN")
    gitlab_clone_timeout_seconds: int = Field(default=120, alias="GITLAB_CLONE_TIMEOUT_SECONDS")

    # --- Scanner settings -------------------------------------------------------
    max_files_to_scan: int = Field(default=4000, alias="MAX_FILES_TO_SCAN")
    max_file_size_bytes: int = Field(default=500_000, alias="MAX_FILE_SIZE_BYTES")
    max_findings_sent_to_llm: int = Field(default=40, alias="MAX_FINDINGS_SENT_TO_LLM")
    snippet_context_lines: int = Field(default=3, alias="SNIPPET_CONTEXT_LINES")

    # --- Storage ------------------------------------------------------------
    data_dir: str = Field(default="/tmp/lumenova_audit_data", alias="AUDIT_DATA_DIR")
    clone_base_dir: str = Field(default="/tmp/lumenova_audit_clones", alias="AUDIT_CLONE_DIR")

    class Config:
        env_file = ".env"
        populate_by_name = True


@lru_cache
def get_settings() -> Settings:
    return Settings()
