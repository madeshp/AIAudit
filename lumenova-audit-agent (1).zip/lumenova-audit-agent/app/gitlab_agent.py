"""
GitLab source checkout agent.

Responsible ONLY for turning a (url, branch, token) tuple into a local
directory containing a checked-out copy of the repository. No audit logic
lives here.
"""
import logging
import shutil
import subprocess
import uuid
from pathlib import Path
from urllib.parse import urlparse, urlunparse

from app.config import get_settings

logger = logging.getLogger("lumenova_audit.gitlab_agent")


class GitLabCheckoutError(RuntimeError):
    pass


def _inject_token(url: str, token: str) -> str:
    """
    Rewrite an https GitLab URL to embed an access token, using the
    'oauth2:<token>@' convention GitLab supports for both PATs and
    project/deploy tokens over HTTPS.
    """
    parsed = urlparse(url)
    if parsed.scheme != "https":
        raise GitLabCheckoutError("Only https:// GitLab URLs are supported")
    netloc = f"oauth2:{token}@{parsed.hostname}"
    if parsed.port:
        netloc += f":{parsed.port}"
    return urlunparse(parsed._replace(netloc=netloc))


def checkout_repository(gitlab_url: str, branch: str, token: str | None, audit_id: str) -> Path:
    """
    Shallow-clones the given branch of a GitLab repo into a unique temp
    directory and returns the local path.

    Raises GitLabCheckoutError on any failure (auth, network, bad branch).
    """
    settings = get_settings()
    dest_root = Path(settings.clone_base_dir)
    dest_root.mkdir(parents=True, exist_ok=True)
    dest_dir = dest_root / f"{audit_id}-{uuid.uuid4().hex[:8]}"

    clone_url = gitlab_url
    effective_token = token or settings.gitlab_default_token
    if effective_token:
        clone_url = _inject_token(gitlab_url, effective_token)

    cmd = [
        "git", "clone",
        "--depth", "1",
        "--branch", branch,
        "--single-branch",
        clone_url,
        str(dest_dir),
    ]

    logger.info("Cloning %s (branch=%s) into %s", gitlab_url, branch, dest_dir)
    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=settings.gitlab_clone_timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        raise GitLabCheckoutError(
            f"Clone timed out after {settings.gitlab_clone_timeout_seconds}s"
        ) from exc

    if result.returncode != 0:
        # Never leak the token into logs/errors
        safe_stderr = result.stderr.replace(effective_token, "***") if effective_token else result.stderr
        raise GitLabCheckoutError(f"git clone failed: {safe_stderr.strip()}")

    return dest_dir


def cleanup_checkout(path: Path) -> None:
    """Best-effort removal of a checked-out repo once the audit is done."""
    try:
        shutil.rmtree(path, ignore_errors=True)
    except Exception:  # noqa: BLE001
        logger.warning("Failed to clean up checkout at %s", path, exc_info=True)
