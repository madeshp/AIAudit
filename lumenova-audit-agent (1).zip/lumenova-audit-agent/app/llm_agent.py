"""
LLM-backed auditor.

Uses the standard OpenAI Python SDK, pointed at OPENAI_BASE_URL, so this
works unmodified against:
  - OpenAI itself
  - Azure OpenAI (with an appropriate base_url/deployment alias)
  - Any other OpenAI-API-compatible gateway (vLLM, LiteLLM proxy, etc.)

The LLM is only ever asked to return strict JSON, which is then validated
against pydantic models — if the model returns something malformed we fail
safe (treat as "not implemented" / "not adequately documented") rather than
guessing.
"""
import json
import logging
from typing import List

from openai import OpenAI

from app.config import get_settings
from app.models import CodeAssessment, DecisionEvidenceAssessment, EvidenceDocument, Finding

logger = logging.getLogger("lumenova_audit.llm_agent")

_CODE_SYSTEM_PROMPT = """You are a meticulous AI compliance auditor. You are given \
excerpts of source code, configuration and documentation extracted from a GitLab \
repository, all of which mention the string "Lumenova" (an AI guardrails product). \
Your job is to determine whether Lumenova guardrails have been genuinely IMPLEMENTED \
in this codebase, as opposed to merely mentioned in a comment, TODO, or unrelated text.

Look for signals such as:
- A dependency on a Lumenova SDK/package/library
- Import statements or API calls invoking Lumenova
- Configuration keys (API keys, endpoints, feature flags) wiring up Lumenova
- Middleware/wrapper code that routes model inputs/outputs through Lumenova

Respond with STRICT JSON ONLY, no markdown fences, matching exactly this schema:
{
  "implemented": <true|false>,
  "confidence": <float 0.0-1.0>,
  "rationale": "<concise explanation citing which findings support your conclusion>",
  "evidence_used": ["<file_path:line_number>", ...]
}
"""

_DECISION_SYSTEM_PROMPT = """You are a meticulous AI compliance auditor evaluating \
whether a team has adequately documented an EXCEPTION decision for the following \
control requirement:

"{requirement_text}"

You are given the text of decision memos, meeting minutes, and/or test reports \
submitted as evidence. Determine whether, taken together, they adequately support \
the claim that:
  1) Lumenova WAS implemented and tested in a lower environment, AND
  2) A documented decision was made that it is NOT required for this specific use case, AND
  3) The rationale for that decision is substantive (not just a bare assertion).

Respond with STRICT JSON ONLY, no markdown fences, matching exactly this schema:
{{
  "adequately_documented": <true|false>,
  "confidence": <float 0.0-1.0>,
  "rationale": "<concise explanation>",
  "missing_elements": ["<what's missing, if anything>", ...]
}}
"""


class LLMAuditor:
    def __init__(self) -> None:
        settings = get_settings()
        if not settings.openai_api_key:
            logger.warning("OPENAI_API_KEY is not set — LLM calls will fail until configured.")
        self._client = OpenAI(api_key=settings.openai_api_key, base_url=settings.openai_base_url)
        self._model = settings.openai_model
        self._temperature = settings.llm_temperature
        self._max_tokens = settings.llm_max_output_tokens

    def _chat_json(self, system_prompt: str, user_prompt: str) -> dict:
        response = self._client.chat.completions.create(
            model=self._model,
            temperature=self._temperature,
            max_tokens=self._max_tokens,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt},
            ],
            response_format={"type": "json_object"},
        )
        raw = response.choices[0].message.content or "{}"
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            logger.error("LLM returned non-JSON output: %s", raw[:500])
            return {}

    def assess_code_implementation(self, findings: List[Finding]) -> CodeAssessment:
        if not findings:
            return CodeAssessment(
                implemented=False,
                confidence=1.0,
                rationale="No mention of Lumenova was found anywhere in the repository.",
                evidence_used=[],
            )

        settings = get_settings()
        limited = findings[: settings.max_findings_sent_to_llm]
        evidence_blob = "\n\n".join(
            f"File: {f.file_path} (line {f.line_number}, category={f.category})\n```\n{f.snippet}\n```"
            for f in limited
        )
        user_prompt = (
            f"Here are {len(limited)} of {len(findings)} findings mentioning 'Lumenova' "
            f"in this repository:\n\n{evidence_blob}"
        )

        data = self._chat_json(_CODE_SYSTEM_PROMPT, user_prompt)
        if not data:
            return CodeAssessment(
                implemented=False,
                confidence=0.0,
                rationale="LLM assessment failed or returned invalid output; failing safe.",
                evidence_used=[],
            )
        return CodeAssessment(
            implemented=bool(data.get("implemented", False)),
            confidence=float(data.get("confidence", 0.0)),
            rationale=str(data.get("rationale", "")),
            evidence_used=list(data.get("evidence_used", [])),
        )

    def assess_decision_evidence(
        self, evidence_documents: List[EvidenceDocument], requirement_text: str
    ) -> DecisionEvidenceAssessment:
        if not evidence_documents:
            return DecisionEvidenceAssessment(
                adequately_documented=False,
                confidence=1.0,
                rationale="No supporting evidence documents (decision memo, meeting "
                          "minutes, test reports) were submitted.",
                missing_elements=["decision memo", "meeting minutes", "test evidence"],
            )

        docs_blob = "\n\n".join(
            f"--- {doc.title} (source: {doc.source or 'unspecified'}) ---\n{doc.content}"
            for doc in evidence_documents
        )
        system_prompt = _DECISION_SYSTEM_PROMPT.format(requirement_text=requirement_text)
        data = self._chat_json(system_prompt, docs_blob)
        if not data:
            return DecisionEvidenceAssessment(
                adequately_documented=False,
                confidence=0.0,
                rationale="LLM assessment failed or returned invalid output; failing safe.",
                missing_elements=[],
            )
        return DecisionEvidenceAssessment(
            adequately_documented=bool(data.get("adequately_documented", False)),
            confidence=float(data.get("confidence", 0.0)),
            rationale=str(data.get("rationale", "")),
            missing_elements=list(data.get("missing_elements", [])),
        )
