"""
Static scanner that walks a checked-out repository looking for signals that
Lumenova (an AI guardrails/governance product) has been integrated.

This is deliberately a *signal extractor*, not a verdict-maker — the LLM
auditor makes the actual judgement call using these findings as evidence.
"""
import logging
import re
from pathlib import Path
from typing import List

from app.config import get_settings
from app.models import Finding

logger = logging.getLogger("lumenova_audit.checker")

# Directories we never want to walk into.
_SKIP_DIRS = {".git", "node_modules", "venv", ".venv", "__pycache__", "dist", "build", ".mypy_cache"}

# Files/extensions worth scanning at all.
_DEPENDENCY_FILES = {
    "requirements.txt", "pyproject.toml", "poetry.lock", "pipfile", "pipfile.lock",
    "package.json", "package-lock.json", "yarn.lock", "pom.xml", "build.gradle",
    "go.mod", "go.sum",
}
_CONFIG_HINTS = {".env", ".yaml", ".yml", ".json", ".toml", ".ini", ".cfg"}
_CODE_EXTENSIONS = {".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb", ".cs"}
_DOC_EXTENSIONS = {".md", ".rst", ".txt"}

_KEYWORD_PATTERN = re.compile(r"lumenova", re.IGNORECASE)


def _categorize(path: Path) -> str:
    name = path.name.lower()
    if name in _DEPENDENCY_FILES:
        return "dependency"
    if path.suffix.lower() in _CONFIG_HINTS or name.startswith(".env"):
        return "config"
    if path.suffix.lower() in _CODE_EXTENSIONS:
        return "code"
    if path.suffix.lower() in _DOC_EXTENSIONS:
        return "docs"
    return "other"


def scan_repository(repo_path: Path, subdirectory: str | None = None) -> List[Finding]:
    """
    Walk the repository (optionally scoped to `subdirectory`) and return a
    list of Finding objects for every line that mentions Lumenova, plus a
    small window of surrounding context.
    """
    settings = get_settings()
    root = repo_path / subdirectory if subdirectory else repo_path
    if not root.exists():
        raise FileNotFoundError(f"Subdirectory '{subdirectory}' not found in repository")

    findings: List[Finding] = []
    files_scanned = 0

    for path in root.rglob("*"):
        if files_scanned >= settings.max_files_to_scan:
            logger.warning("Hit max_files_to_scan limit (%d); stopping scan", settings.max_files_to_scan)
            break
        if path.is_dir():
            continue
        if any(part in _SKIP_DIRS for part in path.parts):
            continue
        try:
            if path.stat().st_size > settings.max_file_size_bytes:
                continue
        except OSError:
            continue

        try:
            text = path.read_text(encoding="utf-8", errors="ignore")
        except (OSError, UnicodeDecodeError):
            continue

        files_scanned += 1
        if not _KEYWORD_PATTERN.search(text):
            continue

        lines = text.splitlines()
        category = _categorize(path)
        rel_path = str(path.relative_to(repo_path))

        for idx, line in enumerate(lines):
            if _KEYWORD_PATTERN.search(line):
                start = max(0, idx - settings.snippet_context_lines)
                end = min(len(lines), idx + settings.snippet_context_lines + 1)
                snippet = "\n".join(lines[start:end])
                findings.append(
                    Finding(
                        file_path=rel_path,
                        line_number=idx + 1,
                        category=category,
                        snippet=snippet[:1000],
                    )
                )

    logger.info("Scanned %d files, found %d Lumenova-related lines", files_scanned, len(findings))
    return findings
