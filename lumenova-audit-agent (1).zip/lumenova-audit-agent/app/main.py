"""
AI Audit Assistant Portal — FastAPI backend.

Endpoints:
  POST /api/v1/audit/submit        Submit evidence (GitLab location + optional
                                    decision memo/minutes) for a control audit.
  GET  /api/v1/audit/{audit_id}    Poll the current status/result of an audit.
  GET  /api/v1/audit               List all audits (most recent first).
  GET  /health                     Liveness probe.
"""
import logging
import uuid

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from app.audit_engine import run_audit
from app.models import AuditReport, AuditStatus, AuditSubmissionRequest, AuditSubmissionResponse
from app.storage import list_reports, load_report

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
logger = logging.getLogger("lumenova_audit.main")

app = FastAPI(
    title="AI Audit Assistant — Lumenova Guardrails Verification Agent",
    description=(
        "Receives GitLab source location evidence submitted via the AI Audit "
        "Assistant portal, checks out the repository, and uses an LLM to "
        "determine whether Lumenova guardrails were implemented — or whether "
        "a documented exception adequately justifies their absence."
    ),
    version="1.0.0",
)

# Adjust for your actual portal's origin in production.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["ops"])
def health():
    return {"status": "ok"}


@app.post("/api/v1/audit/submit", response_model=AuditSubmissionResponse, tags=["audit"])
def submit_audit(request: AuditSubmissionRequest, background_tasks: BackgroundTasks):
    """
    Called by the AI Audit Assistant portal when a user submits evidence for
    the 'AI Guardrails #8 — Lumenova' control. Kicks off an asynchronous
    checkout + scan + LLM evaluation and returns immediately with an audit_id
    the portal can poll.
    """
    audit_id = str(uuid.uuid4())
    logger.info(
        "Received audit submission %s from %s for %s (branch=%s)",
        audit_id, request.submitted_by, request.gitlab_url, request.branch,
    )
    background_tasks.add_task(run_audit, audit_id, request)
    return AuditSubmissionResponse(
        audit_id=audit_id,
        status=AuditStatus.QUEUED,
        message="Audit queued. Poll GET /api/v1/audit/{audit_id} for results.",
    )


@app.get("/api/v1/audit/{audit_id}", response_model=AuditReport, tags=["audit"])
def get_audit(audit_id: str):
    report = load_report(audit_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Audit not found")
    return report


@app.get("/api/v1/audit", response_model=list[AuditReport], tags=["audit"])
def list_audits():
    return list_reports()
