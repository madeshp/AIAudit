"""
Request/response/data models for the AI Audit Assistant portal integration.
"""
from datetime import datetime
from enum import Enum
from typing import List, Optional
from pydantic import BaseModel, Field, HttpUrl


class AuditStatus(str, Enum):
    QUEUED = "queued"
    CLONING = "cloning"
    SCANNING = "scanning"
    EVALUATING = "evaluating"
    COMPLETED = "completed"
    ERROR = "error"


class RequirementVerdict(str, Enum):
    PASSED = "Passed"
    PARTIAL = "Partial"
    FAILED = "Failed"


class EvidenceDocument(BaseModel):
    """
    A piece of documentary evidence submitted alongside the code, e.g. an
    excerpt of meeting minutes or a decision memo. The portal is expected to
    pass the *text content* here (already extracted from Confluence/Word/etc.)
    rather than a binary file.
    """
    title: str = Field(..., description="e.g. 'Lumenova Exception Decision Memo'")
    source: Optional[str] = Field(None, description="e.g. 'Confluence', 'Meeting Minutes 2026-08-01'")
    content: str = Field(..., description="Raw text content of the evidence document")


class AuditSubmissionRequest(BaseModel):
    requirement_id: str = Field(default="AI-Guardrails-8")
    requirement_text: str = Field(
        default=(
            "Provide support for the decision that Lumenova implemented and was "
            "tested in lower environment but determined not required for this "
            "use case (testing evidence, meeting minutes, documented decision)."
        )
    )
    submitted_by: str = Field(..., description="Email or user id of the submitter")

    gitlab_url: HttpUrl = Field(..., description="HTTPS clone URL of the GitLab repository")
    branch: str = Field(default="main")
    gitlab_token: Optional[str] = Field(
        default=None,
        description="Personal/project access token with read_repository scope. "
                    "If omitted, GITLAB_DEFAULT_TOKEN env var is used.",
    )
    subdirectory: Optional[str] = Field(
        default=None, description="Optional path within the repo to restrict scanning to"
    )

    evidence_documents: List[EvidenceDocument] = Field(
        default_factory=list,
        description="Decision memos / meeting minutes / test reports supporting an exception",
    )


class AuditSubmissionResponse(BaseModel):
    audit_id: str
    status: AuditStatus
    message: str


class Finding(BaseModel):
    file_path: str
    line_number: int
    category: str  # dependency | config | code | docs
    snippet: str


class CodeAssessment(BaseModel):
    implemented: bool
    confidence: float
    rationale: str
    evidence_used: List[str] = Field(default_factory=list)


class DecisionEvidenceAssessment(BaseModel):
    adequately_documented: bool
    confidence: float
    rationale: str
    missing_elements: List[str] = Field(default_factory=list)


class AuditReport(BaseModel):
    audit_id: str
    requirement_id: str
    submitted_by: str
    gitlab_url: str
    branch: str
    status: AuditStatus
    verdict: Optional[RequirementVerdict] = None
    created_at: datetime
    updated_at: datetime
    findings_count: int = 0
    code_assessment: Optional[CodeAssessment] = None
    decision_evidence_assessment: Optional[DecisionEvidenceAssessment] = None
    findings: List[Finding] = Field(default_factory=list)
    error: Optional[str] = None
