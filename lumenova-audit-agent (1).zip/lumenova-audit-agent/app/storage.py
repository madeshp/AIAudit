"""
Minimal persistence layer.

For a real production deployment, swap this out for Postgres/DynamoDB/etc.
It's kept as flat JSON files here so the reference agent has zero external
infra dependencies out of the box.
"""
import json
import logging
import threading
from pathlib import Path
from typing import Optional

from app.config import get_settings
from app.models import AuditReport

logger = logging.getLogger("lumenova_audit.storage")
_lock = threading.Lock()


def _report_path(audit_id: str) -> Path:
    settings = get_settings()
    data_dir = Path(settings.data_dir)
    data_dir.mkdir(parents=True, exist_ok=True)
    return data_dir / f"{audit_id}.json"


def save_report(report: AuditReport) -> None:
    with _lock:
        path = _report_path(report.audit_id)
        path.write_text(report.model_dump_json(indent=2), encoding="utf-8")


def load_report(audit_id: str) -> Optional[AuditReport]:
    path = _report_path(audit_id)
    if not path.exists():
        return None
    try:
        return AuditReport.model_validate_json(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        logger.exception("Failed to load report %s", audit_id)
        return None


def list_reports() -> list[AuditReport]:
    settings = get_settings()
    data_dir = Path(settings.data_dir)
    if not data_dir.exists():
        return []
    reports = []
    for path in data_dir.glob("*.json"):
        try:
            reports.append(AuditReport.model_validate_json(path.read_text(encoding="utf-8")))
        except Exception:  # noqa: BLE001
            continue
    return sorted(reports, key=lambda r: r.created_at, reverse=True)
