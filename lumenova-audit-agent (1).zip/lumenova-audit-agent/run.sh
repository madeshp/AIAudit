#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -d ".venv" ]; then
  python3 -m venv .venv
fi
source .venv/bin/activate
pip install -q -r requirements.txt

if [ ! -f ".env" ]; then
  echo "No .env found — copying .env.example. Fill in your OPENAI_API_KEY / GITLAB_DEFAULT_TOKEN."
  cp .env.example .env
fi

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
